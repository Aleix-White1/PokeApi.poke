LMS PokeDex TTF for PC
by London Stokes

This font is Freeware, in that you can use it free of charge
(non commercial purposes only) without getting permission.

If you distribute this font in any way, this zipfile must be kept
intact, without alterations.  This font, with this read-me file may
be made available for downloading from a website.

This font was designed after the font used on the 'pokedex' area of the
www.pokemon.com site.  And to be honest it look better on their site.
Pokemon and PokeDex are both tradmarked words and are used here without
permission.

If you like this font, and feel inclined, please email me at:
RioArizona@hotmail.com and let me know.  It's always a wonderful
feeling to know that your fonts are being downloaded and used!  This
and all my other fonts can be downloaded from the "London's Letters"
web site: http://www.geocities.com/rioarizona/Font.htm


<<<<<<<< CONDITIONS OF USE >>>>>>>>>

1. This font can be used for personal use only. Businesses or companies
   must gain permission for use. 

2. It can not be included in any compilation CD's, disks or product, 
   either commercial or shareware (unless prior permission granted).
   
3. The zipfile containing the font and this text file must be kept
   intact, without alterations, additions or deletions.

4. This font can be transferred, stored or made available to other
   computers or on the internet/bulletin board as long as no fee or
   charge is requested.

5. No warranty is offered, or understood to have been offered by the
   supplier of this font, and the risk of any losses or damage (personal,
   financial or otherwise) from the use of this font remain with the user.

6. The supplier can not be responsible for any problems that may arise
   by misuse of the font. 

7. The term 'Freeware' shall be taken and understood to mean that you
   can use the font, without restrictions.

